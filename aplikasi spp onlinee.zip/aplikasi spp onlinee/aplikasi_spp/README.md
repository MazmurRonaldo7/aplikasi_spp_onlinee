# Aplikasi-Pembayaran-SPP-Berbasis-Website

Fitur Fitur 

* Login Multi User
* Dashboard
* Data SPP
* Data Kelas 
* Data Siswa
* Transaksi Pembayaran
* Laporan 
* LogOut
* Dan Lain - Lain

# Halaman Login

* Login     : admin1
* Password  : admin
